import { Header } from './components/Header';
import { FeatureCard } from './components/FeatureCard';
import { ImportantNote } from './components/ImportantNote';
import { AdditionalUpdates } from './components/AdditionalUpdates';
import { features } from './data/features';
import { PaymentSchedule } from './components/PaymentSchedule';
import { PaymentHistory } from './components/PaymentHistory';
import { AutomaticPayments } from './components/AutomaticPayments';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-6xl mx-auto px-6 py-12">
        <div className="grid gap-8 lg:grid-cols-3 mb-12">
          <div className="lg:col-span-2">
            <PaymentSchedule
              nextPaymentDate="Nov 15, 2024"
              nextPaymentAmount="$1,949.28"
            />
          </div>
          <AutomaticPayments isEnabled={true} />
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3 mb-12">
          {features.map((feature, index) => (
            <FeatureCard key={index} feature={feature} />
          ))}
        </div>

        <ImportantNote />
        <div className="mt-12">
          <PaymentHistory />
        </div>
        <div className="mt-12">
          <AdditionalUpdates />
        </div>
      </main>
    </div>
  );
}

export default App;
