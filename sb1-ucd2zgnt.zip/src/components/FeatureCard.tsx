import { LucideIcon } from 'lucide-react';

interface Feature {
  title: string;
  icon: LucideIcon;
  description: string;
  details?: string[];
}

interface FeatureCardProps {
  feature: Feature;
}

export function FeatureCard({ feature }: FeatureCardProps) {
  const { icon: Icon, title, description, details } = feature;

  return (
    <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex items-center mb-4">
        <div className="p-2 bg-indigo-100 rounded-lg">
          <Icon className="w-6 h-6 text-indigo-600" />
        </div>
        <h3 className="text-xl font-semibold ml-3">{title}</h3>
      </div>
      <p className="text-gray-600 mb-4">{description}</p>
      {details && (
        <ul className="space-y-2">
          {details.map((detail, index) => (
            <li key={index} className="flex items-start">
              <div className="flex-shrink-0 w-1.5 h-1.5 mt-2 rounded-full bg-indigo-500 mr-3" />
              <span className="text-gray-600 text-sm">{detail}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}