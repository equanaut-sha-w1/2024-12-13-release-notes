import { DollarSign, Wallet } from 'lucide-react';

const updates = [
  {
    icon: DollarSign,
    text: 'Removed USDP and TUSD from repayment options',
  },
  {
    icon: Wallet,
    text: '"Custody" tab renamed to "Assets" for better clarity',
  },
];

export function AdditionalUpdates() {
  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-2xl font-semibold mb-6">Additional Updates</h2>
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-gray-900 mb-3">Platform Changes</h3>
          <ul className="space-y-3">
            {updates.map(({ icon: Icon, text }) => (
              <li key={text} className="flex items-start">
                <Icon className="w-5 h-5 text-indigo-600 mr-3 flex-shrink-0" />
                <span className="text-gray-600">{text}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}