interface AutomaticPaymentsProps {
  isEnabled: boolean;
}

export function AutomaticPayments({ isEnabled }: AutomaticPaymentsProps) {
  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <h2 className="text-xl font-semibold mb-4">Automatic Payments</h2>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <span className="text-gray-600">Pay with Collateral</span>
          <button 
            className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:ring-offset-2 ${
              isEnabled ? 'bg-indigo-600' : 'bg-gray-200'
            }`}
            role="switch"
            aria-checked={isEnabled}
          >
            <span
              className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                isEnabled ? 'translate-x-5' : 'translate-x-0'
              }`}
            />
          </button>
        </div>
        <p className="text-sm text-gray-500">
          You're making payments using your liquidated collateral.
        </p>
        <div className="mt-4 rounded-lg bg-red-50 p-4">
          <div className="text-sm text-red-700">
            Unable to change automatic payments within 72 hours of the payment due date.
          </div>
        </div>
      </div>
    </div>
  );
}