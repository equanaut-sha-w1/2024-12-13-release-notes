interface Payment {
  date: string;
  type: string;
  feesPaid: string;
  interestPaid: string;
  principalPaid: string;
  deposit: string;
}

export function PaymentHistory() {
  const hasPayments = false;

  return (
    <div className="bg-white rounded-xl shadow-md p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-semibold">Payment History</h2>
        <button className="text-indigo-600 hover:text-indigo-700">
          <span className="sr-only">Download history</span>
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead>
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fees Paid</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Interest Paid</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Principal Paid</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Deposit</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {!hasPayments && (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-gray-500">
                  No Payments Have Been Made
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}