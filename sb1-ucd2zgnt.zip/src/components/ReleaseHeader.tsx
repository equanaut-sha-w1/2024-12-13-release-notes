import { Calendar, Clock, User } from 'lucide-react';

interface MetadataItem {
  icon: typeof Calendar | typeof Clock | typeof User;
  text: string;
}

const metadata: MetadataItem[] = [
  { icon: Calendar, text: 'Release Notes: 12/12/24' },
  { icon: User, text: 'Brandon West' },
  { icon: Clock, text: 'Last updated: about 6 hours ago' },
];

export function ReleaseHeader() {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white px-6 py-12 md:py-20">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          SALT Platform Updates Are Live!
        </h1>
        <div className="flex flex-wrap gap-4 text-sm opacity-90 mt-6">
          {metadata.map(({ icon: Icon, text }) => (
            <div key={text} className="flex items-center">
              <Icon className="w-4 h-4 mr-2" />
              <span>{text}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}