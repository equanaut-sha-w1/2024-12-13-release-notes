interface LogoProps {
  className?: string;
}

export function Logo({ className = '' }: LogoProps) {
  return (
    <a href="/" className={`flex items-center h-full ${className}`}>
      <img
        src="https://saltlending.com/wp-content/uploads/2022/06/SALT-Logo-White.svg"
        alt="SALT Company Logo - Home"
        className="h-full w-[175px] py-2"
        style={{ objectFit: 'contain' }}
      />
    </a>
  );
}