import { AlertCircle } from 'lucide-react';

export function ImportantNote() {
  return (
    <div className="bg-amber-50 border-l-4 border-amber-400 p-4 rounded-r-lg">
      <div className="flex">
        <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="ml-3">
          <h3 className="text-sm font-medium text-amber-800">Important Note</h3>
          <p className="mt-2 text-sm text-amber-700">
            Payments will not be processed if the loan is in default, LTV would exceed 100%, 
            jurisdiction is frozen, or there's a pending withdrawal from the collateral wallet.
          </p>
        </div>
      </div>
    </div>
  );
}