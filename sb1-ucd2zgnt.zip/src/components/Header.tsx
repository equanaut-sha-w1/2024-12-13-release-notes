import { Logo } from './Logo';

export function Header() {
  return (
    <header className="bg-indigo-600 text-white">
      <div className="max-w-6xl mx-auto px-6 h-16">
        <div className="flex items-center justify-between h-full">
          <Logo />
          <nav className="flex items-center space-x-6">
            <a href="/home" className="text-sm font-medium hover:text-indigo-100">Home</a>
            <a href="/loan" className="text-sm font-medium hover:text-indigo-100">Loan</a>
            <a href="/collateral" className="text-sm font-medium hover:text-indigo-100">Collateral</a>
            <div className="relative group">
              <button className="flex items-center text-sm font-medium hover:text-indigo-100">
                Account & Settings
                <svg className="w-4 h-4 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
}