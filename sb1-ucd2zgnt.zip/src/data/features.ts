import { RefreshCw, MessageSquare, Shield } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';

export interface Feature {
  title: string;
  icon: LucideIcon;
  description: string;
  details?: string[];
}

export const features: Feature[] = [
  {
    title: 'Automated Collateral Liquidations',
    icon: RefreshCw,
    description: 'Streamlined payment processing with automatic execution on the 15th for auto-pay users.',
    details: [
      'Auto-pay: Monthly payments on 15th (no fees)',
      'Non-enrolled: Overdue payments on 18th (1.5% fee)',
      'Smart payment validation and jurisdiction compliance'
    ]
  },
  {
    title: 'Enhanced Error Messaging',
    icon: MessageSquare,
    description: 'Improved validation messages based on provincial loan rules for better clarity.',
  },
  {
    title: 'Borrower Flexibility',
    icon: Shield,
    description: 'Removed 72-hour lock period on repayment adjustments for greater control.',
  }
];